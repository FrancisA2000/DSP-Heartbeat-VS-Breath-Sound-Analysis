/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-K04
 */

#ifndef xconfig_stairstep_JTAGStopMode__
#define xconfig_stairstep_JTAGStopMode__



#endif /* xconfig_stairstep_JTAGStopMode__ */ 

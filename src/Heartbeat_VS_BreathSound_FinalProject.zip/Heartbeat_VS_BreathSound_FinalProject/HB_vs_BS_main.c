/*
 * Copyright (c) 2012-2014, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * */
/*
 *  ======== main.c ======== *
 *  This example is based Template for using UIA service Library
 *  Includes Threads Load Graph, Execution Graph Analysis Features.
 *
 *
 */

 /*  ----------------------------------- XDC module Headers           */
#include <xdc/std.h>

#include <xdc/runtime/Log.h>
#include <xdc/runtime/Timestamp.h>
#include <xdc/runtime/Types.h>
#include <xdc/runtime/Diags.h>
#include <stdio.h>
#include <string.h>
#include <xdc/runtime/System.h>
/*  ----------------------------------- BIOS module Headers           */
#include <ti/sysbios/BIOS.h>

#include <ti/sysbios/knl/Semaphore.h>
#include <ti/sysbios/knl/Swi.h>
#include <ti/sysbios/knl/Task.h>
#include <xdc/cfg/global.h>
#include <math.h>

#include "fdacoefs_NOTCH.h"
#include "fdacoefs_IIR_BS.h"
#include "fdacoefs_IIR_HB.h"
#include "HB_BS_Signal.h"

/**********************************************************************
 ************************** Forward Declarations **********************
 **********************************************************************/

/* RTOS / System functions */
void swi_ISR();
void HB_vs_BS_TASK();
void timerISR();

/* Filter-related functions */
void IIR_Biquad_NOTCH();
void IIR_Biquad_HB();
void IIR_Biquad_BS();

/* Helper / utility functions */
static void resetAllFilters(void);
static float applyTwoStageBiquad(float input, float* state1, float* state2,
                                 const float* coeffsStage1_num, const float* coeffsStage1_den,
                                 const float* coeffsStage2_num, const float* coeffsStage2_den);
static inline float computeEnvelope(float currentEnergy, float prevEnvelope, float taw);
static float smoothRecentValues(const float* arr, int currentIdx, int windowSize);
static float computeArrayAverage(const float* array, int size);
static void detectHalfCycles(const float* window, int windowSize,
                             float* prevAvg, int* isRising, int* halfCycleCount,
                             int idx, int* lastTransitionIdx);

/* Envelope graph generators (stubs, presumably) */
void Envelope_graph_generator_HB();
void Envelope_graph_generator_BS();

/**********************************************************************
 ************************** Global Variables **************************
 **********************************************************************/

/* Buffer size for a single block of data */
#define N 4405
int idx = 0; /* Global sample index */

/* Filtered outputs (Notch, HeartBeat, BreathSound) */
float IIR_filtered_arr_NOTCH[N] = {0};
float IIR_filtered_arr_HB[N]    = {0};
float IIR_filtered_arr_BS[N]    = {0};

/* Energy and Envelope arrays */
float Energy_HB[N]      = {0};
float Energy_BS[N]      = {0};
float Envelope_HB[N]    = {0};
float Envelope_BS[N]    = {0};

/* Current sample read from input buffer (HBvBS) */
float sample = 0.0f;

/*
   Filter states for 2-stage Biquads:
   Each filter has 6 state variables (3 per stage).
   We'll store them in small arrays for convenience:
   stateNOTCH[0..2]  => Stage1, stateNOTCH[3..5] => Stage2, etc.
*/
float stateNOTCH[6] = {0};
float stateHB[6]    = {0};
float stateBS[6]    = {0};

/*
   Decay factor for envelope detection
   Envelope[n] = max(Energy[n], Envelope[n-1] * taw).
*/
float taw = 0.9655f;

/*
   Short-term smoothing window for the envelope arrays
*/
int smoothing_window = 15;

/*
   For breath and heartbeat detection:
   We'll keep separate sliding windows and their indices, etc.
*/
const int WINDOW_SIZE_BS = 2200;
const int WINDOW_SIZE_HB = 500;

float sliding_window_BS[2200] = {0};
float sliding_window_HB[500]  = {0};

int window_idx_BS = 0;
int window_idx_HB = 0;

/* Rising/falling detection for half-cycle counting */
int is_rising_BS = 0;
int is_rising_HB = 0;
int BS_count     = 0;
int HB_count     = 0;

float prev_avg_BS = 0.0f;
float prev_avg_HB = 0.0f;

int last_transition_idx_BS = 0;
int last_transition_idx_HB = 0;

int local_breath_count    = 0;
int local_heartbeat_count = 0;

/**********************************************************************
 ************************** Main (BIOS) *******************************
 **********************************************************************/
int main(Void)
{
    BIOS_start();
    return (0); // Normally never reached
}

/**********************************************************************
 ********************** Software Interrupt (SWI) **********************
 **********************************************************************/
void swi_ISR()
{
    /* Read the sample from the big array that merges HB & BS signals */
    sample = HBvBS[idx];

    /* Signal the main task that a new sample is ready */
    Semaphore_post(sem);
}

/**********************************************************************
 ************************** Main Processing Task **********************
 **********************************************************************
   1) Waits on semaphore for new data
   2) Applies Notch, HB, BS filters
   3) Computes energy, envelope, smoothing
   4) Detects half-cycles for breath/heartbeat
   5) After N=4405 samples, calculates final counts
*/
void HB_vs_BS_TASK()
{
    while (TRUE)
    {
        /* Wait for new sample to be posted by SWI */
        Semaphore_pend(sem, BIOS_WAIT_FOREVER);

        /* Apply Notch filter first */
        IIR_Biquad_NOTCH();
        /* Overwrite sample with the notch-filtered output */
        sample = IIR_filtered_arr_NOTCH[idx];

        /* Then apply HeartBeat and BreathSound filters */
        IIR_Biquad_HB();
        IIR_Biquad_BS();

        /* Compute energies (absolute values) */
        Energy_HB[idx] = (IIR_filtered_arr_HB[idx] >= 0.0f)
                         ? IIR_filtered_arr_HB[idx]
                         : -IIR_filtered_arr_HB[idx];
        Energy_BS[idx] = (IIR_filtered_arr_BS[idx] >= 0.0f)
                         ? IIR_filtered_arr_BS[idx]
                         : -IIR_filtered_arr_BS[idx];

        /* Compute envelopes */
        if (idx == 0) {
            Envelope_HB[idx] = Energy_HB[idx];
            Envelope_BS[idx] = Energy_BS[idx];
        } else {
            Envelope_HB[idx] = computeEnvelope(Energy_HB[idx], Envelope_HB[idx-1], taw);
            Envelope_BS[idx] = computeEnvelope(Energy_BS[idx], Envelope_BS[idx-1], taw);
        }

        /* Smooth the envelopes over the recent samples */
        Envelope_HB[idx] = smoothRecentValues(Envelope_HB, idx, smoothing_window);
        Envelope_BS[idx] = smoothRecentValues(Envelope_BS, idx, smoothing_window);

        /* Update the sliding windows for BS and HB */
        sliding_window_BS[window_idx_BS] = Envelope_BS[idx];
        sliding_window_HB[window_idx_HB] = Envelope_HB[idx];

        /* Detect half-cycles for breath (BS) if we've filled the window */
        if (idx >= WINDOW_SIZE_BS) {
            detectHalfCycles(sliding_window_BS, WINDOW_SIZE_BS,
                             &prev_avg_BS, &is_rising_BS, &BS_count,
                             idx, &last_transition_idx_BS);
        }

        /* Detect half-cycles for heartbeat (HB) if we've filled the window */
        if (idx >= WINDOW_SIZE_HB) {
            detectHalfCycles(sliding_window_HB, WINDOW_SIZE_HB,
                             &prev_avg_HB, &is_rising_HB, &HB_count,
                             idx, &last_transition_idx_HB);
        }

        /* Advance sliding window indices */
        window_idx_BS = (window_idx_BS + 1) % WINDOW_SIZE_BS;
        window_idx_HB = (window_idx_HB + 1) % WINDOW_SIZE_HB;

        /* If we've reached the end of the block (N=4405), compute final counts */
        if (idx == N - 1)
        {

            local_breath_count    = BS_count / 4;
            local_heartbeat_count = HB_count / 2;

            /* Reset everything for the next block */
            BS_count = 0;
            HB_count = 0;
            is_rising_BS   = 0;
            is_rising_HB   = 0;
            prev_avg_BS    = 0.0f;
            prev_avg_HB    = 0.0f;
            window_idx_BS  = 0;
            window_idx_HB  = 0;

            /* Also reset filter states to avoid carry-over */
            resetAllFilters();

            idx = 0; /* wrap around */
        }
        else
        {
            idx++;
        }
    }
}

/**********************************************************************
 ********************** Timer Interrupt (HWI) *************************
 **********************************************************************/
void timerISR()
{
    /* Simply post the SWI that fetches a new sample and signals the task */
    Swi_post(swi0);
}

/**********************************************************************
 ************************ Filter Functions *****************************
 **********************************************************************/

/*
   IIR_Biquad_NOTCH():
   Applies 2-stage notch filter to 'sample'. Outputs to IIR_filtered_arr_NOTCH[idx].
*/
void IIR_Biquad_NOTCH()
{
    /* Two �stages� worth of state are in stateNOTCH[0..5].
       We'll do stage1 as "custom" if needed, or just do a normal 2-stage approach
       if you prefer.
       If your first stage doesn't use standard arrays, you can still unify logic
       or just do direct math. For demonstration, we use the generic approach:
    */

    /*
       If your first stage is truly "barebones" (like original code):
         outStage1 = sample - d1 - d2 + ...
       Otherwise, if you had standard arrays for Notch coefficients, pass them here.
       This example shows generic usage if you had arrays like:
          float NUM_NOTCH_stage1[3], DEN_NOTCH_stage1[3];
          float NUM_NOTCH_stage2[3], DEN_NOTCH_stage2[3];
       But in your code, you have single arrays NUM_NOTCH[] / DEN_NOTCH[];
       you'd just pass them in as stage1 or stage2 as needed.
    */

    /* Example of direct 2-stage usage: */
    /* Stage1: might be trivial or an identity if your code is special. */
    // For demonstration, let's say stage1 is "pass" (no real transform):
    static const float pass_num[3] = {1.0f, 0.0f, 0.0f};
    static const float pass_den[3] = {1.0f, 0.0f, 0.0f};

    /* Stage2: uses actual notch coeffs */
    float outFilter = applyTwoStageBiquad(
        sample,
        &stateNOTCH[0],            /* stage1 states: d0,d1,d2 => stateNOTCH[0..2] */
        &stateNOTCH[3],            /* stage2 states: d0,d1,d2 => stateNOTCH[3..5] */
        pass_num, pass_den,        /* stage1 coefficients (identity or your real ones) */
        NUM_NOTCH, DEN_NOTCH       /* stage2 = actual notch filter */
    );

    IIR_filtered_arr_NOTCH[idx] = outFilter;
}

/*
   IIR_Biquad_HB():
   Applies a 2-stage heartbeat filter (using the structures you had).
   Output is stored in IIR_filtered_arr_HB[idx].
*/
void IIR_Biquad_HB()
{
    float stageMult = NUM_IIR_HB[0][0]; /* Possibly a scale factor for stage1 input or final? */

    /* Stage1 Coeffs: from your arrays (row 1) => NUM_IIR_HB[1], DEN_IIR_HB[1] */
    const float* hb_num_stage1 = NUM_IIR_HB[1];
    const float* hb_den_stage1 = DEN_IIR_HB[1];

    /* Stage2 Coeffs: from your arrays (row 3) => NUM_IIR_HB[3], DEN_IIR_HB[3] */
    const float* hb_num_stage2 = NUM_IIR_HB[3];
    const float* hb_den_stage2 = DEN_IIR_HB[3];

    /* Apply the 2-stage filter in one call */
    float out = applyTwoStageBiquad(
        sample,
        &stateHB[0], &stateHB[3],
        hb_num_stage1, hb_den_stage1,
        hb_num_stage2, hb_den_stage2
    );

    /* Possibly multiply final output by stageMult again if your design requires */
    out *= stageMult;

    IIR_filtered_arr_HB[idx] = out;
}

/*
   IIR_Biquad_BS():
   Applies a 2-stage breath sound filter.
*/
void IIR_Biquad_BS()
{
    float stageMult1 = NUM_IIR_BS[0][0]; /* scale for stage1 input */
    float stageMult2 = NUM_IIR_BS[2][0]; /* scale for final output ( row=2, col=0 ) */

    /* Stage1 Coeffs: from your arrays => row=1 */
    const float* bs_num_stage1 = NUM_IIR_BS[1];
    const float* bs_den_stage1 = DEN_IIR_BS[1];

    /* Stage2 Coeffs: from your arrays => row=3 */
    const float* bs_num_stage2 = NUM_IIR_BS[3];
    const float* bs_den_stage2 = DEN_IIR_BS[3];

    /* We'll feed the sample * stageMult1 if that's your design,
       or just sample if stageMult1=1.
       We can incorporate that logic into applyTwoStageBiquad if you prefer. */
    float firstInput = sample * stageMult1;

    /* Run the 2-stage filter */
    float out = applyTwoStageBiquad(
        firstInput,
        &stateBS[0], &stateBS[3],
        bs_num_stage1, bs_den_stage1,
        bs_num_stage2, bs_den_stage2
    );

    /* Final multiply if needed */
    out *= stageMult2;

    IIR_filtered_arr_BS[idx] = out;
}

/**********************************************************************
 *********************** Helper / Utility Functions ********************
 **********************************************************************/

/*
   Reset all filter states at the start of each 4405-sample block
   to avoid carry-over (your original design).
*/
static void resetAllFilters(void)
{
    int i = 0;
    for (i = 0; i < 6; i++) {
        stateNOTCH[i] = 0.0f;
        stateHB[i]    = 0.0f;
        stateBS[i]    = 0.0f;
    }
}

/*
   Generic function that applies two cascaded biquad stages to 'input'.
   states for stage1 => state1[0..2] = (d0, d1, d2)
   states for stage2 => state2[0..2] = (d0, d1, d2)
   Returns the final output after stage2.
*/
static float applyTwoStageBiquad(float input,
                                 float* state1, float* state2,
                                 const float* coeffsStage1_num,
                                 const float* coeffsStage1_den,
                                 const float* coeffsStage2_num,
                                 const float* coeffsStage2_den)
{
    /* --- Stage 1 --- */
    float d0_1  = input - (state1[1] * coeffsStage1_den[1])
                         - (state1[2] * coeffsStage1_den[2]);
    float out1  = (d0_1 * coeffsStage1_num[0])
                + (state1[1] * coeffsStage1_num[1])
                + (state1[2] * coeffsStage1_num[2]);

    /* Update state1 (shift) */
    state1[2]   = state1[1];
    state1[1]   = d0_1;

    /* --- Stage 2 --- */
    float d0_2  = out1 - (state2[1] * coeffsStage2_den[1])
                        - (state2[2] * coeffsStage2_den[2]);
    float out2  = (d0_2 * coeffsStage2_num[0])
                + (state2[1] * coeffsStage2_num[1])
                + (state2[2] * coeffsStage2_num[2]);

    /* Update state2 (shift) */
    state2[2]   = state2[1];
    state2[1]   = d0_2;

    return out2;
}

/*
   computeEnvelope():
   Envelope[n] = max( currentEnergy, prevEnvelope * taw ).
*/
static inline float computeEnvelope(float currentEnergy, float prevEnvelope, float taw)
{
    return (currentEnergy > prevEnvelope)
           ? currentEnergy
           : (prevEnvelope * taw);
}

/*
   smoothRecentValues():
   Takes up to 'windowSize' points ending at 'arr[currentIdx]'
   and returns the average. If currentIdx < windowSize,
   it only averages up to currentIdx.
*/
static float smoothRecentValues(const float* arr, int currentIdx, int windowSize)
{
    float sum = 0.0f;
    int count = 0;
    int i = 0;
    for (i = 0; i < windowSize && (currentIdx - i) >= 0; i++)
    {
        sum += arr[currentIdx - i];
        count++;
    }
    return (count > 0) ? (sum / (float)count) : 0.0f;
}

/*
   computeArrayAverage():
   Straight average of an array of length 'size'.
*/
static float computeArrayAverage(const float* array, int size)
{
    float sum = 0.0f;
    int i = 0;
    for (i = 0; i < size; i++)
    {
        sum += array[i];
    }
    return (size > 0) ? (sum / (float)size) : 0.0f;
}

/*
   detectHalfCycles():
   1) Compute average of the sliding window
   2) Compare with prevAvg to see if we're rising or falling
   3) On each transition from rising->falling (peak) or falling->rising (trough),
      increment halfCycleCount.
*/
static void detectHalfCycles(const float* window, int windowSize,
                             float* prevAvg, int* isRising, int* halfCycleCount,
                             int idx, int* lastTransitionIdx)
{
    float avg = computeArrayAverage(window, windowSize);

    if (avg > *prevAvg)
    {
        /* Rising phase */
        if (!(*isRising)) {
            /* trough -> half-cycle */
            (*halfCycleCount)++;
            *lastTransitionIdx = idx;
        }
        *isRising = 1;
    }
    else if (avg < *prevAvg)
    {
        /* Falling phase */
        if (*isRising) {
            /* peak -> half-cycle */
            (*halfCycleCount)++;
            *lastTransitionIdx = idx;
        }
        *isRising = 0;
    }
    *prevAvg = avg;
}

/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-G16
 */

#ifndef xconfig_HB_vs_BS__
#define xconfig_HB_vs_BS__



#endif /* xconfig_HB_vs_BS__ */ 
